package com.optimagrowth.gateway;

import org.junit.jupiter.api.Disabled;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiGatewayServerApplicationTests {

	@Disabled
	void contextLoads() {
	}

}
