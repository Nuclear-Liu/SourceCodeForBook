package com.optimagrowth.eureka;

import org.junit.jupiter.api.Disabled;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaServerApplicationTests {

	@Disabled
	void contextLoads() {
	}

}
